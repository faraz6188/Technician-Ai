
const Footer = () => {
  return (
    <footer className="footer py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4 text-white">AI-Powered Field Technician Support</h3>
            <p className="text-sm text-white">
              Your trusted partner for scale maintenance and support.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-white">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/" className="link">Home</a></li>
              <li><a href="/chat" className="link">AI Chat</a></li>
              <li><a href="/video-search" className="link">Video Search</a></li>
              <li><a href="/visual-assist" className="link">Visual Assist</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-white">Support</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="link">Contact Us</a></li>
              <li><a href="#" className="link">FAQs</a></li>
              <li><a href="#" className="link">Technical Support</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 text-white">Legal</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="link">Privacy Policy</a></li>
              <li><a href="#" className="link">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-gray-700 text-sm text-center text-white">
          © {new Date().getFullYear()} AI-Powered Field Technician Support. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
