import React, { createContext, useContext, useEffect, useState } from 'react';
import { pdfHandler } from './pdfHandler';

interface PDFContextType {
  isLoading: boolean;
  loadedManuals: string[];
  searchManuals: (query: string) => Promise<{ 
    results: string[];
    references: Array<{ section: string; page: number }>;
  }>;
}

const PDFContext = createContext<PDFContextType>({
  isLoading: false,
  loadedManuals: [],
  searchManuals: async () => ({ results: [], references: [] }),
});

const manualFiles = [
  { name: 'ACC0048.pdf', url: '/manuals/ACC0048.pdf' },
  { name: 'ABS0131.pdf', url: '/manuals/ABS0131.pdf' },
  { name: 'ABS0130.pdf', url: '/manuals/ABS0130.pdf' },
  { name: 'AOS0832.pdf', url: '/manuals/AOS0832.pdf' },
  { name: 'ACT0021.pdf', url: '/manuals/ACT0021.pdf' },
  { name: 'TMT0158.pdf', url: '/manuals/TMT0158.pdf' }
];

export function PDFProvider({ children }: { children: React.ReactNode }) {
  const [isLoading, setIsLoading] = useState(true);
  const [loadedManuals, setLoadedManuals] = useState<string[]>([]);
  const [loadingQueue, setLoadingQueue] = useState<typeof manualFiles>([]);

  // Load a single manual
  const loadManual = async (file: { name: string; url: string }) => {
    if (loadedManuals.includes(file.name)) return;
    
    try {
      await pdfHandler.loadManual(file);
      setLoadedManuals(prev => [...prev, file.name]);
      console.log(`Successfully loaded manual: ${file.name}`);
    } catch (error) {
      console.error(`Error loading manual ${file.name}:`, error);
    }
  };

  // Initialize manual loading
  useEffect(() => {
    const initializeManuals = async () => {
      setLoadingQueue(manualFiles);
      if (manualFiles.length > 0) {
        // Load first manual immediately
        await loadManual(manualFiles[0]);
        
        // Load remaining manuals in background
        for (let i = 1; i < manualFiles.length; i++) {
          const file = manualFiles[i];
          await loadManual(file);
        }
        
        setIsLoading(false);
      }
    };

    initializeManuals();
  }, []);

  // Search manuals, loading them if needed
  const searchManuals = async (query: string) => {
    try {
      // If no manuals are loaded yet, wait for at least one
      if (loadedManuals.length === 0) {
        const firstManual = loadingQueue[0];
        if (firstManual) {
          await loadManual(firstManual);
        }
      }

      // Search currently loaded manuals
      return pdfHandler.searchManuals(query);
    } catch (error) {
      console.error('Error searching manuals:', error);
      return { results: [], references: [] };
    }
  };

  return (
    <PDFContext.Provider value={{ isLoading, loadedManuals, searchManuals }}>
      {children}
    </PDFContext.Provider>
  );
}

export const usePDF = () => useContext(PDFContext); 