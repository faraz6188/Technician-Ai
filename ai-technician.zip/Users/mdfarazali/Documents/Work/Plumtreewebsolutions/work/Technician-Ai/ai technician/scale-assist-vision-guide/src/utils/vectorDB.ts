import { PDFDocument } from 'pdf-lib';

interface VectorItem {
  vector: number[];
  text: string;
  namespace: string;
  id: number;
}

interface NamespaceMap {
  [key: string]: number;
}

interface IdToText {
  [key: number]: {
    text: string;
    namespace: string;
  };
}

export class VectorDB {
  private baseUrl: string;

  constructor(baseUrl: string = 'http://localhost:8000') {
    this.baseUrl = baseUrl;
  }

  async query(query: string, top_k: number = 5, threshold: number = 0.4): Promise<Array<{
    text: string;
    manual: string;
    similarity: number;
  }>> {
    try {
      const response = await fetch(`${this.baseUrl}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query,
          model_name: "gemini-1.5-flash"
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to query vector database');
      }

      const data = await response.json();
      return data.context.map((item: any) => ({
        text: item.text,
        manual: item.manual,
        similarity: 1.0 // The backend handles similarity scoring
      }));
    } catch (error) {
      console.error('Error querying vector database:', error);
      return [];
    }
  }
} 