
import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: {
        '2xl': '1400px'
      }
    },
    extend: {
      colors: {
        // Standard colors from user request.
        black: "#000000",
        white: "#FFFFFF",
        maroon: "#800000",
        blue: {
          500: "#007BFF",
          600: "#0056b3"
        },
        "gray-800": "#2D2D2D",
        "gray-700": "#333333",
        "gray-600": "#555555",
        "gray-200": "#EEEEEE",
        "red-700": "#660000",
      },
      borderColor: {
        maroon: "#800000",
      }
    }
  },
  plugins: [
    function ({ addUtilities }) {
      addUtilities({
        ".border-maroon": {
          borderColor: "#800000 !important",
        }
      });
    },
    require("tailwindcss-animate")
  ],
} satisfies Config;
