import { pdfjsLib } from './pdfjs-init';

class PDFHandler {
  private manuals: Array<{ name: string; content: string }> = [];

  async loadManual(file: File): Promise<void> {
    try {
      const content = await this.extractPDFContent(file);
      this.manuals.push({
        name: file.name,
        content: content
      });
    } catch (error) {
      console.error('Error loading manual:', error);
      throw error;
    }
  }

  private async extractPDFContent(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        const text = content.items.map((item: any) => item.str).join(' ');
        fullText += text + '\n';
      }
      
      return fullText;
    } catch (error) {
      console.error('Error extracting PDF content:', error);
      throw error;
    }
  }

  getManuals(): Array<{ name: string; content: string }> {
    return this.manuals;
  }
}

export const pdfHandler = new PDFHandler(); 