
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="navbar shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <span className="font-bold text-xl text-white">AI Technician Support</span>
        </div>
        
        <div className="hidden md:flex space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-white hover:text-blue-500"
          >
            Home
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/chat')}
            className="text-white hover:text-blue-500"
          >
            AI Chat
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/video-search')}
            className="text-white hover:text-blue-500"
          >
            Video Search
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/visual-assist')}
            className="text-white hover:text-blue-500"
          >
            Visual Assist
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin')}
            className="text-white hover:text-blue-500"
          >
            Admin
          </Button>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-white"
          >
            {isMenuOpen ? '✕' : '☰'}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden p-4 bg-black shadow-md absolute w-full z-10">
          <div className="flex flex-col space-y-2">
            <Button 
              variant="ghost" 
              onClick={() => {
                navigate('/');
                setIsMenuOpen(false);
              }}
              className="text-white hover:text-blue-500 text-left"
            >
              Home
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => {
                navigate('/chat');
                setIsMenuOpen(false);
              }}
              className="text-white hover:text-blue-500 text-left"
            >
              AI Chat
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => {
                navigate('/video-search');
                setIsMenuOpen(false);
              }}
              className="text-white hover:text-blue-500 text-left"
            >
              Video Search
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => {
                navigate('/visual-assist');
                setIsMenuOpen(false);
              }}
              className="text-white hover:text-blue-500 text-left"
            >
              Visual Assist
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => {
                navigate('/admin');
                setIsMenuOpen(false);
              }}
              className="text-white hover:text-blue-500 text-left"
            >
              Admin
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
