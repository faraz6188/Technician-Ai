import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useToast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";

const VisualAssistPage = () => {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [annotations, setAnnotations] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const analysisIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{text: string, sender: 'user' | 'ai'}>>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  
  // Gemini API key - as requested, using directly in the code
  const API_KEY = "AIzaSyBGWiViiVVGUSB4rQyqAMYKaLDWUDCqBq4";
  
  // Mock AI suggestions for fallback
  const aiSuggestions = [
    "I can see this appears to be a load cell issue. Check for debris underneath the weighing platform.",
    "The display is showing an 'Err 3' code, which typically indicates a calibration problem.",
    "Position the camera to focus on the connection port on the back of the scale.",
    "I notice the power indicator light is blinking. This often indicates low battery.",
    "The level bubble shows the scale is not on a perfectly level surface. Try adjusting the feet.",
    "Move closer to the model number label so I can better assist you with this specific scale."
  ];

  useEffect(() => {
    return () => {
      // Clean up camera stream when component unmounts
      stopCamera();
      
      // Clear any ongoing analysis interval
      if (analysisIntervalRef.current) {
        clearInterval(analysisIntervalRef.current);
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      const constraints = {
        video: { facingMode: 'environment' }
      };
      
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      setIsCameraActive(true);
      startGeminiAnalysis();
      
      toast({
        title: "Camera activated",
        description: "Visual assistance is now analyzing your scale.",
        className: "bg-green-50 border-green-200",
      });
    } catch (err) {
      console.error("Error accessing camera:", err);
      toast({
        variant: "destructive",
        title: "Camera Error",
        description: "Unable to access camera. Please check permissions.",
        className: "bg-red-50 border-red-200",
      });
    }
  };

  const stopCamera = () => {
    // Stop all video tracks
    if (videoRef.current && videoRef.current.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => {
        track.stop();
        track.enabled = false;
      });
      videoRef.current.srcObject = null;
    }

    // Reset video element
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.removeAttribute('src');
      videoRef.current.load();
    }
    
    // Reset canvas
    if (canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        context.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
      }
    }
    
    // Reset states
    setIsCameraActive(false);
    setAnnotations([]);
    setChatMessages([]);
    setChatInput("");
    
    // Clear any ongoing analysis
    if (analysisIntervalRef.current) {
      clearInterval(analysisIntervalRef.current);
      analysisIntervalRef.current = null;
    }
    
    // Stop any ongoing speech
    window.speechSynthesis.cancel();
    
    toast({
      title: "Camera stopped",
      description: "Visual assistance has been deactivated.",
      className: "bg-blue-50 border-blue-200",
    });
  };

  const toggleCamera = () => {
    if (isCameraActive) {
      stopCamera();
    } else {
      startCamera();
    }
  };

  // Function to capture current frame from video
  const captureFrame = (): string | null => {
    if (!videoRef.current || !canvasRef.current) return null;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return null;
    
    // Set canvas dimensions to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw the current video frame to the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Get the image as a base64 encoded string
    return canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
  };

  // Function to analyze image with Gemini 1.5 Flash
  const analyzeImageWithGemini = async (imageBase64: string) => {
    setIsAnalyzing(true);
    
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`;
      
      const payload = {
        contents: [
          {
            parts: [
              {
                text: "You are a technical support assistant for Brechbuhler Scales. Analyze this image and provide a brief, focused response about any visible issues or suggestions. Keep your response under 100 words."
              },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: imageBase64
                }
              }
            ]
          }
        ],
        generation_config: {
          temperature: 0.2, // Reduced for faster, more focused responses
          max_output_tokens: 100, // Reduced for quicker responses
        }
      };
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Gemini API response:", data);
      
      if (data.candidates && data.candidates[0]?.content?.parts) {
        const aiResponse = data.candidates[0].content.parts[0].text;
        
        // Add new annotation
        setAnnotations(prev => [...prev, aiResponse]);
        
        // Speak the annotation if audio is enabled
        if (isAudioEnabled) {
          const utterance = new SpeechSynthesisUtterance(aiResponse);
          speechSynthesis.speak(utterance);
        }
      } else {
        console.error("Unexpected API response format:", data);
        throw new Error("Unexpected API response format");
      }
    } catch (error) {
      console.error("Error calling Gemini API:", error);
      
      // If API fails, fall back to mock data
      fallbackToMockData();
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Fallback to mock data if API fails
  const fallbackToMockData = () => {
    console.log("Falling back to mock data");
    // Switch to mock mode if we encounter API issues
    setUseGemini(false);
    
    // Add a message about the fallback
    const fallbackMessage = "AI connection issue detected.";
    setAnnotations(prev => [...prev, fallbackMessage]);
    
    if (isAudioEnabled) {
      const utterance = new SpeechSynthesisUtterance(fallbackMessage);
      speechSynthesis.speak(utterance);
    }
    
    // Start mock analysis after a short delay
    setTimeout(() => {
      if (isCameraActive) {
        startMockAnalysis();
      }
    }, 2000);
  };

  const startGeminiAnalysis = () => {
    // Clear any existing annotations
    setAnnotations([]);
    
    // Analyze frames periodically
    analysisIntervalRef.current = setInterval(() => {
      if (!isCameraActive || isAnalyzing) return;
      
      const imageBase64 = captureFrame();
      if (imageBase64) {
        analyzeImageWithGemini(imageBase64);
      }
    }, 10000); // Analyze every 10 seconds to avoid excessive API calls
  };

  const startMockAnalysis = () => {
    // Clear any existing annotations if not already in fallback mode
    if (annotations.length === 0) {
      setAnnotations([]);
    }
    
    // Simulate periodic AI analysis and feedback
    let index = 0;
    
    analysisIntervalRef.current = setInterval(() => {
      if (index < aiSuggestions.length) {
        // Add new annotation
        setAnnotations(prev => [...prev, aiSuggestions[index]]);
        
        // Speak the annotation if audio is enabled
        if (isAudioEnabled) {
          const utterance = new SpeechSynthesisUtterance(aiSuggestions[index]);
          speechSynthesis.speak(utterance);
        }
        
        index++;
      } else {
        if (analysisIntervalRef.current) {
          clearInterval(analysisIntervalRef.current);
          analysisIntervalRef.current = null;
        }
      }
    }, 5000);
  };

  const toggleAudio = () => {
    setIsAudioEnabled(!isAudioEnabled);
    toast({
      title: isAudioEnabled ? "Audio disabled" : "Audio enabled",
      description: isAudioEnabled 
        ? "Voice guidance has been turned off." 
        : "You will now hear voice guidance.",
      className: isAudioEnabled ? "bg-blue-50 border-blue-200" : "bg-green-50 border-green-200",
    });
  };

  // Add new function for chat-based analysis
  const handleChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !isCameraActive) return;

    const userMessage = chatInput.trim();
    setChatMessages(prev => [...prev, { text: userMessage, sender: 'user' }]);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const imageBase64 = captureFrame();
      if (!imageBase64) {
        throw new Error("Failed to capture image");
      }

      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${API_KEY}`;
      
      const payload = {
        contents: [
          {
            parts: [
              {
                text: `You are a technical support assistant. The user asks: "${userMessage}". Analyze this image and provide a brief detailed, focused response. Keep your response problem solving enough detailed.`
              },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: imageBase64
                }
              }
            ]
          }
        ],
        generation_config: {
          temperature: 0.2,
          max_output_tokens: 100,
        }
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) throw new Error(`API error: ${response.status}`);
      
      const data = await response.json();
      if (data.candidates?.[0]?.content?.parts) {
        const aiResponse = data.candidates[0].content.parts[0].text;
        setChatMessages(prev => [...prev, { text: aiResponse, sender: 'ai' }]);
        
        if (isAudioEnabled) {
          const utterance = new SpeechSynthesisUtterance(aiResponse);
          speechSynthesis.speak(utterance);
        }
      }
    } catch (error) {
      console.error("Error in chat analysis:", error);
      setChatMessages(prev => [...prev, { 
        text: "I encountered an error while analyzing your question. Please try again.", 
        sender: 'ai' 
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Visual Assistance</h1>
        
        <Tabs defaultValue="camera" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="camera">Live Camera</TabsTrigger>
            <TabsTrigger value="guide">How To Use</TabsTrigger>
          </TabsList>
          
          <TabsContent value="camera">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="overflow-hidden">
                  <div className="relative bg-black aspect-video">
                    {!isCameraActive && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                        <div className="text-5xl mb-4">📷</div>
                        <p className="text-xl mb-4">Camera is currently off</p>
                        <Button 
                          onClick={startCamera}
                          className="bg-scales-blue hover:bg-scales-lightBlue"
                        >
                          Start Camera
                        </Button>
                      </div>
                    )}
                    
                    <video 
                      ref={videoRef}
                      className={`w-full h-full object-cover ${isCameraActive ? 'block' : 'hidden'}`}
                      autoPlay
                      playsInline
                      muted
                    ></video>
                    
                    <canvas 
                      ref={canvasRef}
                      className="absolute top-0 left-0 w-full h-full pointer-events-none"
                    ></canvas>
                  </div>
                  
                  <div className="p-4 flex flex-col gap-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <Label htmlFor="audio-toggle" className="text-gray-700 font-medium">Voice Guidance</Label>
                        <Button
                          onClick={toggleAudio}
                          className={`px-4 py-1 rounded-full text-sm font-medium transition-colors ${
                            isAudioEnabled 
                              ? 'bg-green-500 hover:bg-green-600 text-white' 
                              : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                          }`}
                        >
                          {isAudioEnabled ? 'ON' : 'OFF'}
                        </Button>
                      </div>
                      
                      <Button
                        onClick={toggleCamera}
                        className={isCameraActive 
                          ? "bg-red-500 hover:bg-red-600 text-white" 
                          : "bg-green-500 hover:bg-green-600 text-white"
                        }
                      >
                        {isCameraActive ? "Stop Camera" : "Start Camera"}
                      </Button>
                    </div>

                    {/* New Chat Section */}
                    {isCameraActive && (
                      <div className="mt-4 border-t pt-4">
                        <form onSubmit={handleChatSubmit} className="flex gap-2">
                          <Input
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            placeholder="Ask about what you see in the camera..."
                            className="flex-grow"
                            disabled={isChatLoading}
                          />
                          <Button 
                            type="submit" 
                            disabled={!chatInput.trim() || isChatLoading}
                            className="bg-scales-blue hover:bg-scales-lightBlue"
                          >
                            {isChatLoading ? "Sending..." : "Send"}
                          </Button>
                        </form>

                        <div className="mt-4 space-y-3 max-h-[200px] overflow-y-auto">
                          {chatMessages.map((msg, index) => (
                            <div 
                              key={index} 
                              className={`p-3 rounded-lg ${
                                msg.sender === 'ai' 
                                  ? 'bg-blue-50 border border-blue-200 ml-4' 
                                  : 'bg-gray-50 border border-gray-200 mr-4'
                              }`}
                            >
                              <div className="font-semibold mb-1">
                                {msg.sender === 'ai' ? 'AI Assistant' : 'You'}:
                              </div>
                              <div>{msg.text}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              </div>
              
              <div>
                <Card className="h-full">
                  <CardContent className="pt-6">
                    <h3 className="text-lg font-bold mb-4">AI Feedback</h3>
                    
                    {annotations.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        {isCameraActive 
                          ? isAnalyzing 
                            ? "Analyzing your scale... Please wait."
                            : "Waiting for analysis... Point camera at your scale."
                          : "Start the camera to receive AI guidance."}
                      </div>
                    ) : (
                      <div className="space-y-3 max-h-[400px] overflow-y-auto">
                        {annotations.map((note, index) => (
                          <div key={index} className="p-3 bg-blue-50 rounded text-sm">
                            <div className="font-semibold mb-1 text-scales-blue">AI Assistant:</div>
                            <div>{note}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="guide">
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-2xl font-bold mb-4">How to Use Visual Assistance</h2>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-bold mb-2">Step 1: Prepare Your Device</h3>
                    <p className="text-gray-700">
                      Ensure your device has a working camera and you've granted permission for this application to access it. 
                      Good lighting will help the AI analyze your scale more accurately.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">Step 2: Position Your Camera</h3>
                    <p className="text-gray-700">
                      Point your camera at the scale you need help with. Try to capture the entire scale or focus on the specific part you're having issues with.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">Step 3: Start the Visual Assistant</h3>
                    <p className="text-gray-700">
                      Click the "Start Camera" button to activate the visual assistant. Our AI will begin analyzing your scale and providing feedback.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">Step 4: Follow AI Guidance</h3>
                    <p className="text-gray-700">
                      The AI may ask you to reposition your camera, focus on specific parts, or take actions to resolve your issue. Follow these instructions for the best assistance.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">Voice Guidance</h3>
                    <p className="text-gray-700">
                      The assistant can provide voice instructions to guide you hands-free. Toggle voice guidance on or off using the switch below the video feed.
                    </p>
                  </div>
                </div>
                
                <div className="mt-8 border-t pt-6">
                  <h3 className="text-lg font-bold mb-2">Tips for Best Results</h3>
                  <ul className="list-disc list-inside space-y-2 text-gray-700">
                    <li>Ensure good lighting conditions</li>
                    <li>Keep the camera steady</li>
                    <li>Follow the AI's instructions to reposition when needed</li>
                    <li>Speak clearly if using voice controls</li>
                    <li>Make sure the scale's display is visible if relevant to your issue</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
};
 
export default VisualAssistPage;
