import { NextApiRequest, NextApiResponse } from 'next';
import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY || '');

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  try {
    const { messages, manualReferences } = req.body;

    // Get the last message which contains our enhanced prompt
    const lastMessage = messages[messages.length - 1];

    // Create chat model
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    const chat = model.startChat({
      history: messages.slice(0, -1).map(msg => ({
        role: msg.role,
        parts: msg.content,
      })),
    });

    // Generate response
    const result = await chat.sendMessage(lastMessage.content);
    const response = await result.response;
    const text = response.text();

    // Format the response with manual references if available
    let formattedResponse = text;
    if (manualReferences && manualReferences.length > 0) {
      formattedResponse += '\n\nReferences:\n';
      manualReferences.forEach(ref => {
        formattedResponse += `- ${ref.section}, page ${ref.page}\n`;
      });
    }

    return res.status(200).json({ content: formattedResponse });
  } catch (error) {
    console.error('Error in chat API:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
} 