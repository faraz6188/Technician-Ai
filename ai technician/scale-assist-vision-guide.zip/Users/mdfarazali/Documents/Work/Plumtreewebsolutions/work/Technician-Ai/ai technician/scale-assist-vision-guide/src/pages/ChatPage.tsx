import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useToast } from "@/components/ui/use-toast";

// Types and Interfaces
type Message = {
  id: number;
  content: string;
  sender: "user" | "ai";
  context?: Array<{
    manual: string;
    text: string;
  }>;
};

// API URL configuration - can be set based on environment
const API_URL = 'http://127.0.0.1:8000';  // Using 127.0.0.1 instead of localhost

// Default model to use - matching the backend configuration
const DEFAULT_MODEL = "gemini-2.0-flash-lite-001";

const ChatPage = () => {
  const [inputValue, setInputValue] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: Date.now(),
      content: "Hello! I'm BrechTech, your Brechbuhler Scales technical expert. I can help you with questions about scale operation, maintenance, and troubleshooting using our technical manuals. How can I assist you today?",
      sender: "ai",
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [isApiAvailable, setIsApiAvailable] = useState(true);
  const [loadedManuals, setLoadedManuals] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    scrollToBottom();
    
    // Check API health on component mount
    checkApiHealth();
  }, [messages]);

  const checkApiHealth = async () => {
    const maxRetries = 3;
    let retryCount = 0;

    const checkConnection = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000); // Reduced timeout to 3 seconds

        const response = await fetch(`${API_URL}/health`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        if (response.ok) {
          const data = await response.json();
          setIsApiAvailable(true);
          setLoadedManuals(data.loaded_manuals || []);
          
          if (data.loaded_manuals && data.loaded_manuals.length === 0) {
            toast({
              title: "No Manuals Loaded",
              description: "Please add PDF files to: /src/manuals",
              variant: "default",
            });
          }
          return true;
        }
        return false;
      } catch (error) {
        console.error(`API health check attempt ${retryCount + 1} failed:`, error);
        return false;
      }
    };

    while (retryCount < maxRetries) {
      const success = await checkConnection();
      if (success) return;
      
      retryCount++;
      if (retryCount === maxRetries) {
        setIsApiAvailable(false);
        toast({
          title: "Backend Connection Error",
          description: "Please ensure the backend server is running with: cd backend && uvicorn main:app --reload",
          variant: "destructive",
        });
      } else {
        await new Promise(resolve => setTimeout(resolve, 1000)); // Reduced wait time to 1 second
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newMessage: Message = {
      id: Date.now(),
      content: inputValue,
      sender: 'user'
    };

    setMessages(prev => [...prev, newMessage]);
    setInputValue('');
    setIsTyping(true);

    const maxRetries = 3;
    let retryCount = 0;

    while (retryCount < maxRetries) {
      try {
        if (!isApiAvailable) {
          throw new Error('Backend service is not available');
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000);

        const response = await fetch(`${API_URL}/query`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: inputValue,
            model_name: DEFAULT_MODEL
          }),
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.detail || `Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        setMessages(prev => [...prev, {
          id: Date.now(),
          content: data.answer,
          sender: 'ai',
          context: data.context
        }]);
        return;

      } catch (error) {
        console.error(`Query attempt ${retryCount + 1} failed:`, error);
        retryCount++;

        if (retryCount === maxRetries) {
          toast({
            title: "Error",
            description: error instanceof Error ? error.message : "An unexpected error occurred after multiple attempts",
            variant: "destructive",
          });
          
          setMessages(prev => [...prev, {
            id: Date.now(),
            content: "I encountered an error while processing your request. Please try again or contact support if the issue persists.",
            sender: 'ai'
          }]);
    } else {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      } finally {
        if (retryCount === maxRetries) {
          setIsTyping(false);
        }
      }
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">Technical Support Assistant</h1>
        
        {!isApiAvailable && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4" role="alert">
            <p className="font-bold">Warning</p>
            <p>Cannot connect to the backend service. The assistant may not respond correctly.</p>
          </div>
        )}
        
        {isApiAvailable && loadedManuals.length === 0 && (
          <div className="bg-blue-100 border-l-4 border-blue-500 text-blue-700 p-4 mb-4" role="alert">
            <p className="font-bold">Information</p>
            <p>No technical manuals have been loaded. Please add PDF files to the manuals directory.</p>
          </div>
        )}
        
        {isApiAvailable && loadedManuals.length > 0 && (
          <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p className="font-bold">Available Manuals</p>
            <p>Loaded manuals: {loadedManuals.join(", ")}</p>
          </div>
        )}
        
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="h-[500px] flex flex-col">
              <div className="flex-grow overflow-y-auto mb-4 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                  className={`p-4 rounded-lg ${
                    message.sender === "ai" 
                      ? "bg-blue-50 text-gray-800" 
                      : "bg-gray-100 text-gray-800"
                  }`}
                >
                  <div className="font-bold mb-1">
                      {message.sender === "ai" ? "Assistant" : "You"}
                    </div>
                  <div className="whitespace-pre-wrap">{message.content}</div>
                  {message.context && message.context.length > 0 && message.sender === "ai" && (
                    <Accordion type="single" collapsible className="mt-3">
                      <AccordionItem value="sources">
                        <AccordionTrigger className="text-sm text-blue-600">
                          View Sources ({message.context.length})
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="mt-2 text-sm text-gray-600 max-h-40 overflow-y-auto">
                            {message.context.map((source, index) => (
                              <div key={index} className="mt-2 p-2 border-l-2 border-blue-200">
                                <span className="font-medium">{source.manual}:</span>
                                <div className="text-gray-700">{source.text}</div>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  )}
                  </div>
                ))}
                {isTyping && (
                <div className="p-4 rounded-lg bg-blue-50">
                  <div className="font-bold mb-1">Assistant</div>
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
              
              <form onSubmit={handleSubmit} className="flex space-x-2">
              <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask about your scale..."
                className="flex-grow"
                disabled={!isApiAvailable || isTyping}
              />
              <Button 
                type="submit" 
                disabled={!inputValue.trim() || !isApiAvailable || isTyping}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6"
              >
                Send
              </Button>
              </form>
            </div>
            </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default ChatPage;
