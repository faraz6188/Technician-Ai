import { Routes as RouterRoutes, Route } from 'react-router-dom';
import Index from './pages/Index';
import ChatPage from './pages/ChatPage';
import VideoSearchPage from './pages/VideoSearchPage';
import VisualAssistPage from './pages/VisualAssistPage';
import AdminPage from './pages/AdminPage';
import NotFound from './pages/NotFound';

const Routes = () => {
  return (
    <RouterRoutes>
      <Route path="/" element={<Index />} />
      <Route path="/chat" element={<ChatPage />} />
      <Route path="/video-search" element={<VideoSearchPage />} />
      <Route path="/visual-assist" element={<VisualAssistPage />} />
      <Route path="/admin" element={<AdminPage />} />
      <Route path="*" element={<NotFound />} />
    </RouterRoutes>
  );
};

export default Routes; 