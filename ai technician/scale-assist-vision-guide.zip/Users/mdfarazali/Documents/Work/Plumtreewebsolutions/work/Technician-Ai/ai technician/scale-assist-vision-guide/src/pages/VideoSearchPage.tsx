import React, { useState } from 'react';
import { GoogleGenerativeAI } from '@google/generative-ai';

const API_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

// Initialize the Gemini client
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Video knowledge base with titles
const videoKnowledgeBase = [
  {
    title: "How to replace an evaporator coil step by step",
    url: "https://youtu.be/dDQM_MGwA8g?si=OsPw4JqAsxmwzAq8"
  },
  {
    title: "How to Evacuate an AC system, Full Vacuum Procedure",
    url: "https://youtu.be/JsnQeUSuUMU?si=7NNcq4UeTtPh2Gs7"
  },
  {
    title: "How a Heat Pump Reversing Valve Works",
    url: "https://youtu.be/lFV3xT5HCH0?si=5ZUk90x8uU9qkWqB"
  },
  {
    title: "How to Properly Pipe a Drain on a Fan Coil",
    url: "https://youtu.be/3sbrTLwmNRo?si=x5k6eNnRghkfGC2J"
  },
  {
    title: "How to Leak Test an AC With Nitrogen Pressure",
    url: "https://youtu.be/JaSUDn2VU04?si=zW_TBuxDMO1svz-g"
  },
  {
    title: "How A Typical Refrigeration Cooler Works - Pump Down Refrigeration in 3D",
    url: "https://youtu.be/ihFvHsx3868?si=mWZfNF16CSv2hosz"
  }
];

// Function to extract video ID from YouTube URL
function extractVideoId(url: string): string | null {
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : null;
}

export default function Home() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);
  const [videoId, setVideoId] = useState<string | null>(null);

  // Function to find video answers using Gemini
  async function findVideoAnswerWithGemini(question: string) {
    try {
      setLoading(true);
      setVideoId(null); // Reset video ID
      
      // Construct the prompt with clear instructions
      const prompt = `You are a helpful assistant that provides answers about HVAC systems, refrigeration, and related technical topics. Here are the available videos:

${videoKnowledgeBase.map(video => `- ${video.title}: ${video.url}`).join('\n')}

Based on the user's question: "${question}", provide a helpful answer and recommend ONE most relevant video from the knowledge base above. Your response should:
1. Answer the question clearly and concisely
2. Include EXACTLY ONE video from the knowledge base that best matches the user's specific problem or question
3. Format the video URL on a new line starting with "Video URL:" followed by the URL
4. Briefly explain why this specific video is relevant to the user's question
5. If possible, mention any specific timestamps or sections in the video that are most relevant

Example format:
[Your detailed answer here]

Video URL: [YouTube URL here]
This video is relevant because: [Brief explanation of relevance]

Question: ${question}`;

      // Generate content using Gemini
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      setAnswer(text || "I couldn't find relevant information in the video knowledge base.");

      // Extract video ID from the response if it contains a YouTube URL
      // First try to find the URL that's explicitly marked as "Video URL:"
      let urlMatch = text.match(/Video URL:\s*(https:\/\/youtu\.be\/[a-zA-Z0-9_-]+)/);
      
      // If not found, look for any YouTube URL in the response
      if (!urlMatch) {
        urlMatch = text.match(/https:\/\/youtu\.be\/[a-zA-Z0-9_-]+/);
      }
      
      if (urlMatch) {
        const videoId = extractVideoId(urlMatch[1] || urlMatch[0]);
        if (videoId) {
          setVideoId(videoId);
        }
      }
    } catch (error) {
      console.error("Error finding video answer with Gemini:", error);
      setAnswer("An error occurred while trying to find the answer using Gemini.");
    } finally {
      setLoading(false);
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (question.trim()) {
      findVideoAnswerWithGemini(question);
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '2rem' }}>
        AI Video Search Assistant
      </h1>
      
      <form onSubmit={handleSubmit} style={{ marginBottom: '2rem' }}>
        <div style={{ marginBottom: '1rem' }}>
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question about industrial scales..."
            style={{
              width: '100%',
              padding: '10px',
              fontSize: '16px',
              borderRadius: '4px',
              border: '1px solid #ccc'
            }}
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          style={{
            width: '100%',
            padding: '10px',
            fontSize: '16px',
            backgroundColor: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: loading ? 'not-allowed' : 'pointer'
          }}
        >
          {loading ? 'Searching...' : 'Search Videos'}
        </button>
      </form>

      {answer && (
        <div style={{
          padding: '20px',
          backgroundColor: '#f8f9fa',
          borderRadius: '4px',
          marginTop: '2rem'
        }}>
          <h2 style={{ marginBottom: '1rem' }}>Answer:</h2>
          <div style={{ whiteSpace: 'pre-wrap' }}>{answer}</div>
          
          {videoId && (
            <div style={{ marginTop: '2rem' }}>
              <h3 style={{ marginBottom: '1rem' }}>Relevant Video:</h3>
              <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
                <iframe
                  src={`https://www.youtube.com/embed/${videoId}`}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    border: 'none',
                    borderRadius: '4px'
                  }}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>
          )}
        </div>
      )}

      <div style={{ marginTop: '3rem' }}>
        <h2 style={{ marginBottom: '1rem' }}>Available Videos:</h2>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {videoKnowledgeBase.map((video, index) => (
            <li
              key={index}
              style={{
                padding: '10px',
                backgroundColor: index % 2 === 0 ? '#f8f9fa' : 'white',
                borderRadius: '4px'
              }}
            >
              <a
                href={video.url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: '#007bff', textDecoration: 'none' }}
              >
                {video.title}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
} 