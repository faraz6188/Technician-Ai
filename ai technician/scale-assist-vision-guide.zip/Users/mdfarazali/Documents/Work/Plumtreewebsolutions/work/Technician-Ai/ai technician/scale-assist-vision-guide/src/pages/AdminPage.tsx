
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useToast } from "@/components/ui/use-toast";

interface VideoStats {
  id: number;
  title: string;
  views: number;
  avgWatchTime: string;
}

interface AIStats {
  date: string;
  queries: number;
  satisfaction: number;
}

const AdminPage = () => {
  const { toast } = useToast();
  const [videoTitle, setVideoTitle] = useState("");
  const [videoDescription, setVideoDescription] = useState("");
  const [videoCategory, setVideoCategory] = useState("");
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [manualTitle, setManualTitle] = useState("");
  const [manualFile, setManualFile] = useState<File | null>(null);

  // Mock video statistics
  const videoStats: VideoStats[] = [
    { id: 1, title: "Scale Calibration Tutorial", views: 1245, avgWatchTime: "3:42" },
    { id: 2, title: "Troubleshooting Error Codes", views: 986, avgWatchTime: "5:18" },
    { id: 3, title: "Connecting Scale to POS Systems", views: 732, avgWatchTime: "4:05" },
    { id: 4, title: "Cleaning and Maintenance Guide", views: 548, avgWatchTime: "2:56" },
  ];

  // Mock AI statistics
  const aiStats: AIStats[] = [
    { date: "2025-04-15", queries: 126, satisfaction: 92 },
    { date: "2025-04-16", queries: 142, satisfaction: 94 },
    { date: "2025-04-17", queries: 118, satisfaction: 89 },
    { date: "2025-04-18", queries: 153, satisfaction: 91 },
    { date: "2025-04-19", queries: 132, satisfaction: 93 },
    { date: "2025-04-20", queries: 95, satisfaction: 90 },
    { date: "2025-04-21", queries: 144, satisfaction: 95 },
  ];

  const handleVideoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    toast({
      title: "Video Uploaded",
      description: `"${videoTitle}" has been added to the library.`,
    });
    
    // Reset form
    setVideoTitle("");
    setVideoDescription("");
    setVideoCategory("");
    setVideoFile(null);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    toast({
      title: "Manual Uploaded",
      description: `"${manualTitle}" has been added to the knowledge base.`,
    });
    
    // Reset form
    setManualTitle("");
    setManualFile(null);
  };

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setFile: React.Dispatch<React.SetStateAction<File | null>>
  ) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
        
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="upload">Upload Content</TabsTrigger>
            <TabsTrigger value="stats">Usage Statistics</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upload">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Upload Video</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleVideoSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="video-title">Video Title</Label>
                      <Input
                        id="video-title"
                        value={videoTitle}
                        onChange={(e) => setVideoTitle(e.target.value)}
                        placeholder="Enter video title"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="video-description">Description</Label>
                      <Textarea
                        id="video-description"
                        value={videoDescription}
                        onChange={(e) => setVideoDescription(e.target.value)}
                        placeholder="Enter video description"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="video-category">Category</Label>
                      <Select
                        value={videoCategory}
                        onValueChange={setVideoCategory}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                          <SelectItem value="troubleshooting">Troubleshooting</SelectItem>
                          <SelectItem value="usage">Usage</SelectItem>
                          <SelectItem value="integration">Integration</SelectItem>
                          <SelectItem value="software">Software</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="video-file">Video File</Label>
                      <Input
                        id="video-file"
                        type="file"
                        accept="video/*"
                        onChange={(e) => handleFileChange(e, setVideoFile)}
                        required
                      />
                      {videoFile && (
                        <p className="text-sm text-gray-500">
                          Selected: {videoFile.name}
                        </p>
                      )}
                    </div>
                    
                    <Button type="submit" className="w-full bg-scales-blue hover:bg-scales-lightBlue">
                      Upload Video
                    </Button>
                  </form>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Upload Manual</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleManualSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="manual-title">Manual Title</Label>
                      <Input
                        id="manual-title"
                        value={manualTitle}
                        onChange={(e) => setManualTitle(e.target.value)}
                        placeholder="Enter manual title"
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="manual-file">PDF File</Label>
                      <Input
                        id="manual-file"
                        type="file"
                        accept=".pdf"
                        onChange={(e) => handleFileChange(e, setManualFile)}
                        required
                      />
                      {manualFile && (
                        <p className="text-sm text-gray-500">
                          Selected: {manualFile.name}
                        </p>
                      )}
                    </div>
                    
                    <Button type="submit" className="w-full bg-scales-blue hover:bg-scales-lightBlue">
                      Upload Manual
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="stats">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Video Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2">Video</th>
                          <th className="text-right py-2">Views</th>
                          <th className="text-right py-2">Avg. Watch Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {videoStats.map((stat) => (
                          <tr key={stat.id} className="border-b">
                            <td className="py-3">{stat.title}</td>
                            <td className="text-right py-3">{stat.views}</td>
                            <td className="text-right py-3">{stat.avgWatchTime}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>AI Chat Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2">Date</th>
                          <th className="text-right py-2">Queries</th>
                          <th className="text-right py-2">Satisfaction %</th>
                        </tr>
                      </thead>
                      <tbody>
                        {aiStats.map((stat, index) => (
                          <tr key={index} className="border-b">
                            <td className="py-3">{stat.date}</td>
                            <td className="text-right py-3">{stat.queries}</td>
                            <td className="text-right py-3">{stat.satisfaction}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
};

export default AdminPage;
