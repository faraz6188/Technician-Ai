import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();
  const features = [{
    title: "AI Chat Support",
    description: "Get instant answers to your questions with our AI-powered chatbot.",
    icon: "🤖",
    link: "/chat",
    buttonText: "Chat Now"
  }, {
    title: "Video Snippet Search",
    description: "Find specific video tutorials and guides for your scale.",
    icon: "🎥",
    link: "/video-search",
    buttonText: "Search Video"
  }, {
    title: "Live Visual Assistance",
    description: "Use your camera for real-time AI-powered visual guidance.",
    icon: "📷",
    link: "/visual-assist",
    buttonText: "Take Guidance"
  }];

  return <div className="flex flex-col min-h-screen bg-white">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-black text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">Welcome to AI-Powered Field Technician Support</h1>
            <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-8 text-white">
              Your comprehensive support platform for all your scale maintenance and troubleshooting needs
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button onClick={() => navigate('/chat')} className="cta-btn">
                Start Chat
              </button>
              <button onClick={() => navigate('/video-search')} className="cta-btn bg-white text-blue-500 hover:bg-gray-200 hover:text-blue-600 border-blue-500 border">
                Browse Videos
              </button>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-black">Our Support Modes</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature, index) => <div key={index} className="image-frame transition-transform hover:scale-105">
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-2 text-black">{feature.title}</h3>
                  <p className="text-gray-600 mb-6">{feature.description}</p>
                  <button onClick={() => navigate(feature.link)} className="cta-btn">
                    {feature.buttonText}
                  </button>
                </div>)}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-black">How It Works</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">1</div>
                <h3 className="text-xl font-bold mb-2 text-black">Choose Support Mode</h3>
                <p className="text-gray-600">Select the type of assistance that best suits your needs.</p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">2</div>
                <h3 className="text-xl font-bold mb-2 text-black">Describe Your Issue</h3>
                <p className="text-gray-600">Explain your problem or ask questions via text or visuals.</p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">3</div>
                <h3 className="text-xl font-bold mb-2 text-black">Get Expert Guidance</h3>
                <p className="text-gray-600">Receive immediate AI-powered assistance and solutions.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>;
};
export default Index;
