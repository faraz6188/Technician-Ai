import type { AppProps } from 'next/app';
import { PDFProvider } from '@/utils/PDFContext';

export default function App({ Component, pageProps }: AppProps) {
  return (
    <PDFProvider>
      <Component {...pageProps} />
    </PDFProvider>
  );
} 