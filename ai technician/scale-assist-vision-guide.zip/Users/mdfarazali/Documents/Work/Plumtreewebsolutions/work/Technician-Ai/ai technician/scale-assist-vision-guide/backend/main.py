from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import google.generativeai as genai
import PyPDF2
from typing import List, Dict, Optional
import os
from dotenv import load_dotenv
import numpy as np
from pydantic import BaseModel, ConfigDict
import faiss
from sentence_transformers import SentenceTransformer
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure Gemini AI with your specific API key
GOOGLE_API_KEY = "AIzaSyCJk8-Ie33ElsdCf3o-hGR4tAb-29kpU8E"
DEFAULT_MODEL = "gemini-2.0-flash-lite-001"

genai.configure(api_key=GOOGLE_API_KEY)

# Use SentenceTransformer for embeddings
embed_model = SentenceTransformer("all-minilm-l6-v2")

class VectorDB:
    def __init__(self, dimension: int, index_name: str = "default_index"):
        self.index = faiss.IndexFlatL2(dimension)
        self.index_name = index_name
        self.namespace_map = {}
        self.dimension = dimension
        self.id_to_text = {}

    def create_index(self):
        if self.index is None:
            self.index = faiss.IndexFlatL2(self.dimension)

    def store(self, vectors, texts, namespace):
        if self.index is None:
            self.create_index()

        if namespace not in self.namespace_map:
            self.namespace_map[namespace] = 0
        offset = self.namespace_map[namespace]
        ids = [offset + i for i in range(len(vectors))]
        self.index.add(np.array(vectors))
        
        for i, text in enumerate(texts):
            self.id_to_text[ids[i]] = {"text": text, "namespace": namespace}
        self.namespace_map[namespace] = offset + len(vectors)

    def query(self, vector, top_k, namespace):
        if self.index is None:
            logger.warning("Warning: index is None")
            return []
        distances, faiss_ids = self.index.search(np.array([vector]), top_k)
        results = []
        for i, id in enumerate(faiss_ids[0]):
            if id in self.id_to_text and self.id_to_text[id]['namespace'] == namespace:
                text = self.id_to_text[id]['text']
                results.append((distances[0][i], text))
        return results

    def delete(self, namespace):
        if namespace in self.namespace_map:
            offset = self.namespace_map[namespace]
            ids_to_delete = [offset + i for i in range(self.namespace_map[namespace])]
            self.index.remove_ids(np.array(ids_to_delete))
            del self.namespace_map[namespace]
        else:
            logger.warning(f"Namespace {namespace} not found.")

def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        with open(pdf_path, "rb") as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() or ""
    except Exception as e:
        logger.error(f"Error extracting text from {pdf_path}: {e}")
        return ""
    return text

def chunk_text(text, chunk_size=500, overlap=50):
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        chunks.append(chunk)
        start = end - overlap
    return chunks

def get_embeddings(texts):
    embeddings = embed_model.encode(texts).tolist()
    return embeddings

def store_embeddings(vector_db, texts, embeddings, namespace):
    vector_db.store(vectors=embeddings, texts=texts, namespace=namespace)

def retrieve_relevant_chunks(vector_db, query, namespace, top_k=5):
    query_embedding = embed_model.encode([query]).tolist()[0]
    results = vector_db.query(vector=query_embedding, top_k=top_k, namespace=namespace)
    relevant_chunks = [text for _, text in results]
    return relevant_chunks

def generate_response(query, context_chunks, model_name=DEFAULT_MODEL):
    context = "\n\n".join(context_chunks)
    prompt = f"""
    You are a technical support assistant for Brechbuhler Scales. Use the information below to answer the user's question.
    Context:
    {context}

    User Question:
    {query}
    """
    try:
        # Use the specified model
        model = genai.GenerativeModel(model_name)
        response = model.generate_content(prompt)
        return response.text if response.text else "I couldn't find relevant information in the knowledge base."
    except Exception as e:
        logger.error(f"Error generating response with model {model_name}: {e}")
        return "I encountered an error while processing your request. Please try again with a different question."

class QueryRequest(BaseModel):
    query: str
    model_config: ConfigDict = ConfigDict(protected_namespaces=())
    model_name: Optional[str] = DEFAULT_MODEL

class QueryResponse(BaseModel):
    answer: str
    context: List[Dict[str, str]]

# Initialize vector database
vector_db = VectorDB(dimension=384, index_name="tech-support-index")

# Define the base directory for manuals
MANUALS_DIR = "/Users/mdfarazali/Documents/Work/Plumtreewebsolutions/work/ai technician/scale-assist-vision-guide/src/manuals"

# Create manuals directory if it doesn't exist
os.makedirs(MANUALS_DIR, exist_ok=True)

# Load PDFs on startup
@app.on_event("startup")
async def startup_event():
    logger.info("Starting up and loading PDF files...")
    
    # Look for PDF files in the manuals directory
    try:
        pdf_files = [f for f in os.listdir(MANUALS_DIR) if f.endswith('.pdf')]
        
        if not pdf_files:
            logger.warning(f"No PDF files found in {MANUALS_DIR}")
            # Create a sample manual for testing if no files exist
            with open(os.path.join(MANUALS_DIR, "sample.pdf"), "wb") as f:
                sample_pdf = PyPDF2.PdfWriter()
                page = sample_pdf.add_blank_page(width=612, height=792)
                sample_pdf.write(f)
            pdf_files = ["sample.pdf"]
    except Exception as e:
        logger.error(f"Error accessing manuals directory: {e}")
        pdf_files = []
        
    # Process each PDF file
    for pdf_file in pdf_files:
        file_path = os.path.join(MANUALS_DIR, pdf_file)
        try:
            pdf_text = extract_text_from_pdf(file_path)
            if pdf_text:
                text_chunks = chunk_text(pdf_text)
                embeddings = get_embeddings(text_chunks)
                pdf_filename = os.path.splitext(os.path.basename(file_path))[0]
                store_embeddings(vector_db, text_chunks, embeddings, namespace=pdf_filename)
                logger.info(f"Successfully processed {pdf_filename}")
            else:
                logger.warning(f"No text extracted from {pdf_file}")
        except Exception as e:
            logger.error(f"Error processing {file_path}: {e}")

@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    try:
        logger.info(f"Processing query: {request.query} using model: {request.model_name}")
        
        # Use the specified model or default
        model_to_use = request.model_name or DEFAULT_MODEL
        
        # Get all namespaces (PDF filenames)
        namespaces = list(vector_db.namespace_map.keys())
        
        if not namespaces:
            return QueryResponse(
                answer="No manuals have been loaded into the system. Please add PDF files to the manuals directory.",
                context=[]
            )
        
        # Query across all PDFs
        relevant_chunks = []
        manual_contexts = []
        
        for namespace in namespaces:
            chunks = retrieve_relevant_chunks(vector_db, request.query, namespace=namespace)
            
            # Add chunks to the overall collection
            relevant_chunks.extend(chunks)
            
            # Format context for each manual
            for chunk in chunks:
                manual_contexts.append({
                    "manual": namespace,
                    "text": chunk
                })
        
        # Generate response
        if not relevant_chunks:
            answer = "I couldn't find relevant information in the technical manuals. Please try a different question or provide more details."
        else:
            answer = generate_response(request.query, relevant_chunks, model_to_use)
        
        return QueryResponse(
            answer=answer,
            context=manual_contexts
        )
            
    except Exception as e:
        logger.error(f"Unexpected error in process_query: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

# Health check endpoint
@app.get("/health")
def health_check():
    return {
        "status": "healthy", 
        "model": DEFAULT_MODEL,
        "loaded_manuals": list(vector_db.namespace_map.keys())
    }

# Export the app for ASGI
app = app
